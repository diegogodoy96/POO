package ar.org.centro8.java.curso.tn_poo_tp_02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TnPooTp02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
